
import net.sourceforge.jFuzzyLogic.FIS;

public class SistemaExpertoFuzzy {
    public static void main(String[] args) {
        String archivo = "sistema_experto.fcl";
        FIS fis = FIS.load(archivo, true);

        if (fis == null) {
            System.err.println("No se pudo cargar el archivo FCL");
            return;
        }

        fis.setVariable("temperatura", 35);
        fis.setVariable("humedad", 70);

        fis.evaluate();

        double riesgo = fis.getVariable("riesgo").getValue();
        System.out.println("Nivel de riesgo: " + riesgo);

        fis.chart();
    }
}
